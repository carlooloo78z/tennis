// Independent scoring state. Standard advantage sets and seven-point tiebreaks.
export class TennisScore {
  constructor(bestOf=1, gamesToWin=6) {
    this.bestOf=bestOf; this.gamesToWin=gamesToWin; this.points=[0,0];
    this.games=[0,0]; this.sets=[0,0]; this.history=[]; this.server=0;
    this.tie=false; this.tieFirst=0; this.winner=null; this.totalPoints=0;
  }
  display() {
    if(this.tie) return this.points.map(String);
    const [a,b]=this.points;
    if(a>=3&&b>=3) return a===b?['40','40']:a>b?['AD','40']:['40','AD'];
    return this.points.map(p=>['0','15','30','40'][Math.min(p,3)]);
  }
  wouldWinGame(side) {
    const a=this.points[side]+1,b=this.points[1-side];
    return a>=(this.tie?7:4)&&a-b>=2;
  }
  pressure() {
    for(let side=0;side<2;side++) if(this.wouldWinGame(side)) {
      const winsSet=this.tie || (this.games[side]+1>=this.gamesToWin&&this.games[side]+1-this.games[1-side]>=2);
      if(winsSet) return this.sets[side]+1>this.bestOf/2?'MATCH POINT':'SET POINT';
      if(side!==this.server) return 'BREAK POINT';
    }
    return this.points[0]>=3&&this.points[0]===this.points[1]&&!this.tie?'DEUCE':this.tie?'TIEBREAK':'';
  }
  point(side) {
    if(this.winner!==null) return {match:this.winner};
    this.points[side]++; this.totalPoints++;
    const event={point:side};
    if(this.points[side]>=(this.tie?7:4)&&this.points[side]-this.points[1-side]>=2) {
      this.games[side]++; event.game=side; this.points=[0,0];
      if(this.tie || (this.games[side]>=this.gamesToWin&&this.games[side]-this.games[1-side]>=2)) {
        this.history.push([...this.games]); this.sets[side]++; event.set=side;
        this.server=this.tie?1-this.tieFirst:1-this.server;
        this.games=[0,0]; this.tie=false;
        if(this.sets[side]>this.bestOf/2){this.winner=side;event.match=side;}
      } else {
        this.server=1-this.server;
        if(this.games[0]===this.gamesToWin&&this.games[1]===this.gamesToWin){this.tie=true;this.tieFirst=this.server;}
      }
    } else if(this.tie) {
      const n=this.points[0]+this.points[1];
      this.server=(this.tieFirst+(Math.floor((n+1)/2)%2))%2;
    }
    return event;
  }
  get deuceSide(){return (this.points[0]+this.points[1])%2===0;}
}
