export const COURT={halfWidth:4.115,doublesWidth:5.485,halfLength:11.885,service:6.4,net:.914};
export const SURFACES={
  hard:{name:'Pacific Open',location:'INDIAN WELLS · USA',label:'Hard court',color:0x24799a,outer:0x174d55,accent:'#c8f36a',bounce:.77,friction:.79,sky:0xb9cfda},
  clay:{name:'Terra Masters',location:'MONTE CARLO · MONACO',label:'Clay court',color:0xbd6746,outer:0x955239,accent:'#ffd8af',bounce:.83,friction:.68,sky:0xcbd7dd},
  grass:{name:'The Royal Club',location:'LONDON · UNITED KINGDOM',label:'Grass court',color:0x4c8454,outer:0x2c6044,accent:'#d6e7a6',bounce:.65,friction:.87,sky:0xd4dfe6},
  indoor:{name:'Midnight Arena',location:'TOKYO · JAPAN',label:'Indoor hard',color:0x485b9e,outer:0x21283e,accent:'#bfb4ff',bounce:.78,friction:.82,sky:0x101828}
};
export const SHOTS={
 topspin:{name:'TOPSPIN',time:1.13,arc:1.65,spin:5.8,speed:1},
 slice:{name:'SLICE',time:1.14,arc:.9,spin:-2.5,speed:.83},
 flat:{name:'FLAT DRIVE',time:.94,arc:1.2,spin:.7,speed:1.14},
 lob:{name:'LOB',time:2.16,arc:5.4,spin:1.4,speed:.66},
 smash:{name:'SMASH',time:.76,arc:.5,spin:1.6,speed:1.35}
};
export const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export const length=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
export function newBall(){return {x:0,y:1,z:12,vx:0,vy:0,vz:0,spin:0,curve:0,bounces:0,lastHit:0,serving:false,netTouch:false,live:false};}
// 120 Hz integration; drag, gravity and spin act on velocity, never position snaps.
export function integrate(ball,dt,surface) {
  const oldZ=ball.z,oldY=ball.y;
  const drag=Math.exp(-.075*dt);
  ball.vx=(ball.vx+ball.curve*dt)*drag; ball.vz*=drag;
  ball.vy-=(9.81+Math.max(-2,ball.spin*.42))*dt;
  ball.x+=ball.vx*dt;ball.y+=ball.vy*dt;ball.z+=ball.vz*dt;
  let net=false,bounce=false,tape=false;
  if(oldZ*ball.z<0&&Math.abs(ball.x)<6.05){
    const h=oldY+(ball.y-oldY)*Math.abs(oldZ)/(Math.abs(oldZ)+Math.abs(ball.z));
    const netH=.914+.156*Math.pow(Math.abs(ball.x)/5.485,2);
    if(h<netH+.034){ball.netTouch=true;if(h>netH-.025){tape=true;ball.vz*=.83;ball.vy=Math.max(.2,ball.vy*.3);}else{net=true;ball.z=Math.sign(oldZ)*.04;ball.vz*=-.12;ball.vx*=.4;ball.vy*=.25;}}
  }
  if(ball.y<.034&&ball.vy<0){
    ball.y=.034;ball.vy=-ball.vy*surface.bounce*clamp(1+ball.spin*.02,.78,1.1);
    const kick=1+ball.spin*.012;
    ball.vx*=surface.friction*kick;ball.vz*=surface.friction*kick;
    ball.bounces++;ball.spin*=.6;bounce=true;
  }
  return {net,bounce,tape};
}
// Solve initial velocity by shooting against the exact integrator used in play.
export function launch(ball,target,shot='topspin',power=.55,serve=false) {
  const s=SHOTS[shot],distance=Math.hypot(target.x-ball.x,target.z-ball.z);
  const time=serve?clamp(.82-power*.22,.51,.82):clamp(s.time*(distance/20)**.32*(1.1-power*.2),.62,2.6);
  ball.spin=serve?3:s.spin;ball.curve=0;
  const g=9.81+Math.max(-2,ball.spin*.42),drag=.075;
  const f=(1-Math.exp(-drag*time))/drag;
  ball.vx=(target.x-ball.x)/f;ball.vz=(target.z-ball.z)/f;
  ball.vy=(.034-ball.y+.5*g*time*time)/time;
  if(shot==='lob')ball.vy+=.45;
  ball.bounces=0;ball.netTouch=false;ball.live=true;ball.serving=serve;
  return Math.hypot(ball.vx,ball.vz,ball.vy)*3.6;
}
export function predict(ball,surface,maxTime=3){
  const copy={...ball}; let time=0;
  while(time<maxTime){const e=integrate(copy,1/60,surface);time+=1/60;if(e.bounce)return {...copy,time};}
  return {...copy,time};
}
