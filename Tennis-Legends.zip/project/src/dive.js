export const DIVE={duration:.44,recovery:.5,cooldown:1.8,staminaCost:.28,speed:11.5,reach:2.45};

export function divePose(player){
  if(player.diveTime>0){
    const progress=1-player.diveTime/DIVE.duration;
    const lean=Math.min(1,progress/.18);
    return {tilt:1.35*lean,height:.16*lean+.35*Math.sin(progress*Math.PI),stretch:lean};
  }
  if(player.diveRecovery>0){
    const remaining=player.diveRecovery/DIVE.recovery;
    return {tilt:1.35*remaining**1.5,height:.16*remaining,stretch:remaining};
  }
  return null;
}
