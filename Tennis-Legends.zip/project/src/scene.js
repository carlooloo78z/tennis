import * as THREE from 'three';
import {SURFACES,clamp} from './physics.js';
import {divePose} from './dive.js';
const mat=(color,roughness=.8)=>new THREE.MeshStandardMaterial({color,roughness});
export class CourtScene {
 constructor(canvas,settings){
  this.settings=settings;this.scene=new THREE.Scene();this.scene.background=new THREE.Color(0xb9cfda);this.scene.fog=new THREE.Fog(0xb9cfda,65,135);
  this.camera=new THREE.PerspectiveCamera(45,innerWidth/innerHeight,.1,180);this.camera.position.set(23,22,30);this.look=new THREE.Vector3(0,0,0);
  this.renderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});this.renderer.setPixelRatio(Math.min(devicePixelRatio,1.8));this.renderer.setSize(innerWidth,innerHeight);this.renderer.shadowMap.enabled=true;this.renderer.shadowMap.type=THREE.PCFSoftShadowMap;this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.2;
  this.scene.add(new THREE.HemisphereLight(0xe5f4ff,0x748779,2));this.sun=new THREE.DirectionalLight(0xffefcf,3.1);this.sun.position.set(-15,28,12);this.sun.castShadow=true;this.sun.shadow.mapSize.set(2048,2048);Object.assign(this.sun.shadow.camera,{left:-26,right:26,top:30,bottom:-30,near:1,far:80});this.sun.shadow.bias=-.0003;this.scene.add(this.sun);
  this.world=new THREE.Group();this.scene.add(this.world);this.players=[];this.effects=[];this.time=0;this.surface='hard';this.buildCourt();
  this.ball=new THREE.Mesh(new THREE.SphereGeometry(.092,16,12),mat(0xdfff3b));this.ball.castShadow=true;this.scene.add(this.ball);
  const seam=new THREE.Mesh(new THREE.TorusGeometry(.093,.005,4,32),mat(0xffffdf));seam.rotation.x=.7;this.ball.add(seam);
  this.ballShadow=new THREE.Mesh(new THREE.CircleGeometry(.15,24),new THREE.MeshBasicMaterial({color:0x142a22,transparent:true,opacity:.38,depthWrite:false}));this.ballShadow.rotation.x=-Math.PI/2;this.scene.add(this.ballShadow);
  this.marker=new THREE.Mesh(new THREE.RingGeometry(.36,.42,40),new THREE.MeshBasicMaterial({color:0xe3f795,side:THREE.DoubleSide,transparent:true,opacity:.7}));this.marker.rotation.x=-Math.PI/2;this.scene.add(this.marker);
  this.target=new THREE.Group();const tr=new THREE.Mesh(new THREE.RingGeometry(.62,.68,48),new THREE.MeshBasicMaterial({color:0xc9ff72,transparent:true,opacity:.85,side:THREE.DoubleSide}));tr.rotation.x=-Math.PI/2;this.target.add(tr);const dot=new THREE.Mesh(new THREE.CircleGeometry(.12,20),tr.material);dot.rotation.x=-Math.PI/2;this.target.add(dot);this.scene.add(this.target);this.target.visible=false;
  this.trail=[];for(let i=0;i<9;i++){let m=new THREE.Mesh(new THREE.SphereGeometry(.045*(1-i/12),6,4),new THREE.MeshBasicMaterial({color:0xe5ff6f,transparent:true,opacity:.35*(1-i/9),depthWrite:false}));this.scene.add(m);this.trail.push(m);}
  addEventListener('resize',()=>this.resize());
 }
 resize(){this.camera.aspect=innerWidth/innerHeight;this.camera.updateProjectionMatrix();this.renderer.setSize(innerWidth,innerHeight);}
 mesh(geometry,material,x,y,z,parent=this.world){const m=new THREE.Mesh(geometry,material);m.position.set(x,y,z);m.receiveShadow=true;parent.add(m);return m;}
 box(w,h,d,color,x,y,z,parent){return this.mesh(new THREE.BoxGeometry(w,h,d),typeof color==='number'?mat(color):color,x,y,z,parent);}
 textTexture(text,color='#e4eddf',bg='#102f36',w=1024,h=128){const c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);ctx.fillStyle=color;ctx.textAlign='center';ctx.textBaseline='middle';ctx.font=`600 ${h*.38}px Arial`;ctx.fillText(text,w/2,h/2);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t;}
 label(text,x,y,z,w=7,h=.8,ry=0,bg='#102f36'){const m=this.mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:this.textTexture(text,'#edf0e4',bg),side:THREE.DoubleSide}),x,y,z);m.rotation.y=ry;m.userData.board=y>.3&&y<2&&(Math.abs(x)>13||Math.abs(z)>18);m.userData.label=text;return m;}
 courtTexture(){const c=document.createElement('canvas');c.width=c.height=512;const ctx=c.getContext('2d');ctx.fillStyle='#ffffff';ctx.fillRect(0,0,512,512);for(let i=0;i<28000;i++){const n=180+Math.random()*60;ctx.fillStyle=`rgba(${n},${n},${n},.35)`;ctx.fillRect(Math.random()*512,Math.random()*512,1.5,1.5);}const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(4,8);t.colorSpace=THREE.SRGBColorSpace;return t;}
 buildCourt(){
  this.world.clear();this.stadiumTheme=null;const s=SURFACES[this.surface];this.scene.background.set(s.sky);this.scene.fog.color.set(s.sky);this.sun.intensity=this.surface==='indoor'?1.3:3.1;
  this.box(150,.3,150,0x2b4a43,0,-.25,0);this.box(30,.1,44,s.outer,0,-.04,0);
  const material=mat(s.color);material.map=this.texture??=this.courtTexture();this.box(10.97,.025,23.77,material,0,.018,0);
  if(this.surface==='grass')for(let i=0;i<12;i++)if(i%2===0)this.box(10.96,.005,1.98,mat(0x528b59),0,.033,-10.89+i*1.98);
  const line=mat(0xf3f3df);const stripe=(w,d,x,z)=>this.box(w,.012,d,line,x,.044,z);
  for(const x of [-5.485,-4.115,4.115,5.485])stripe(.05,23.82,x,0);
  for(const z of [-11.885,11.885]){stripe(11.02,.07,0,z);stripe(.05,.18,0,z-Math.sign(z)*.08);}
  for(const z of [-6.4,6.4])stripe(8.23,.05,0,z);stripe(.05,12.8,0,0);
  // A real open mesh net; the transparent weave keeps the far court readable.
  const netC=document.createElement('canvas');netC.width=64;netC.height=64;const nc=netC.getContext('2d');nc.strokeStyle='#14282d';nc.lineWidth=3;nc.strokeRect(0,0,64,64);const nt=new THREE.CanvasTexture(netC);nt.wrapS=nt.wrapT=THREE.RepeatWrapping;nt.repeat.set(95,9);
  const net=this.mesh(new THREE.PlaneGeometry(12,.92),new THREE.MeshStandardMaterial({map:nt,transparent:true,side:THREE.DoubleSide,roughness:1}),0,.49,0);net.castShadow=true;
  this.box(12,.045,.045,0xeeeede,0,.96,0);this.box(.035,.93,.035,0xf0eee0,0,.49,.015);
  for(const x of [-6,6]){const post=this.mesh(new THREE.CylinderGeometry(.07,.085,1.12,12),mat(0x203936),x,.55,0);post.castShadow=true;}
  for(const z of [-19,19]){
    this.box(29,1.4,.4,0x132f35,0,.7,z);
    for(let i=-1;i<=1;i++)this.label(i===0?'T E N N I S   L E G E N D S':i<0?'COURTSIDE  /  CLUB':'PRECISION IN PLAY',i*9, .8,z-Math.sign(z)*.215,8,.8,z>0?Math.PI:0);
  }
  for(const x of [-13.8,13.8]){this.box(.35,1.3,38,0x15363a,x,.65,0);for(const z of [-12,-4,4,12])this.label('LEGENDS',x-Math.sign(x)*.19,.8,z,6,.7,x<0?Math.PI/2:-Math.PI/2);}
  const seatMat=mat(this.surface==='clay'?0x638c7a:this.surface==='indoor'?0x343958:0x46767b);
  for(let row=0;row<7;row++){
    for(const zsign of [-1,1])this.box(35,.45,1.35,seatMat,0,.4+row*.65,zsign*(20+row*1.25));
    for(const xsign of [-1,1])this.box(1.35,.45,39,seatMat,xsign*(15+row*1.25),.4+row*.65,0);
  }
  const crowdGeo=new THREE.SphereGeometry(.22,6,5),crowdMat=mat(0xffffff);this.crowd=new THREE.InstancedMesh(crowdGeo,crowdMat,1600);let n=0;const dummy=new THREE.Object3D(),palette=[0xe9ddc1,0x31485e,0xaabbab,0xebb99b,0xc57867,0x6192a1,0xd6e1e4,0x3d4d38];
  for(let row=0;row<7;row++)for(let j=0;j<45;j++)for(const side of [-1,1]){dummy.position.set((j-22)*.72,.98+row*.65,side*(20+row*1.25));dummy.scale.set(1,1.65,1);dummy.updateMatrix();this.crowd.setMatrixAt(n,dummy.matrix);this.crowd.setColorAt(n++,new THREE.Color(palette[Math.floor(Math.random()*palette.length)]));}
  for(let row=0;row<6;row++)for(let j=0;j<48;j++)for(const side of [-1,1]){dummy.position.set(side*(15+row*1.25),.98+row*.65,(j-24)*.75);dummy.scale.set(1,1.6,1);dummy.updateMatrix();this.crowd.setMatrixAt(n,dummy.matrix);this.crowd.setColorAt(n++,new THREE.Color(palette[Math.floor(Math.random()*palette.length)]));}
  this.crowd.count=n;this.world.add(this.crowd);
  // Stadium trusses and lamps.
  for(const x of [-12.5,12.5])for(const z of [-17,17]){
   this.box(.16,14,.16,0xa4b4b4,x,7,z);this.box(3,.22,.5,0x323f43,x,14,z);
   for(let i=-1;i<=1;i++)this.box(.65,.36,.25,new THREE.MeshStandardMaterial({color:0xffffff,emissive:0xfff5cf,emissiveIntensity:2}),x+i,13.8,z-.18);
   if(this.surface==='indoor'){let light=new THREE.PointLight(0xbdd9ff,60,38);light.position.set(x,12,z);this.world.add(light);}
  }
  if(this.surface==='indoor'){for(const z of [-24,-12,0,12,24])this.box(51,.25,.35,0x435065,0,18,z);const ceiling=this.mesh(new THREE.PlaneGeometry(52,60),mat(0x121b2d),0,19,0);ceiling.rotation.x=Math.PI/2;}
  else for(let i=0;i<24;i++){const x=(i%2?1:-1)*(28+Math.random()*12),z=(Math.random()-.5)*80;this.mesh(new THREE.CylinderGeometry(.2,.35,5,6),mat(0x4c4c3d),x,2,z);this.mesh(new THREE.ConeGeometry(2.8,8,7),mat(0x385f4c),x,8,z);}
  // Umpire chair, ladders, courtside benches and attendants.
  for(const x of [-7.2,-6.6]){this.box(.06,2.5,.06,0xe1ded1,x,1.25,.6);this.box(.06,2.5,.06,0xe1ded1,x,1.25,-.6);}this.box(.85,.12,1.4,0xf0eee3,-6.9,2.45,0);this.box(.8,.7,.1,0x244d49,-6.9,2.8,.7);
  for(let y=.3;y<2.4;y+=.35)this.box(.65,.05,.06,0xdad9d0,-6.9,y,.65);
  for(const z of [-8,8]){this.box(.7,.13,3.2,0xefeadb,9,.65,z);for(const dz of [-1.3,1.3])this.box(.5,.6,.12,0x40534f,9,.3,z+dz);}
  for(const [x,z] of [[-10,-16],[10,-16],[-10,16],[10,16],[-6.9,0]]){const g=this.createPlayer({shirt:'#425c69',shorts:'#dddccb',skin:'#b78361',hair:'#292923',shoes:'#eeeeee',racket:'#4b5c5a',accessory:'none'});g.root.position.set(x,x===-6.9?2.1:0,z);g.root.scale.setScalar(.82);g.racket.visible=false;this.world.add(g.root);}
  this.label(s.name.toUpperCase(),0,.06,15.2,7,1.0,0).rotation.x=-Math.PI/2;
 }
 createPlayer(a){
  const root=new THREE.Group(),body=new THREE.Group();root.add(body);const skin=mat(a.skin),shirt=mat(a.shirt),shorts=mat(a.shorts),shoe=mat(a.shoes),hair=mat(a.hair);
  const piece=(geo,m,x,y,z,parent=body)=>this.mesh(geo,m,x,y,z,parent);
  const torso=piece(new THREE.CylinderGeometry(.25,.21,.62,10),shirt,0,1.1,0);torso.castShadow=true;
  piece(new THREE.SphereGeometry(.27,12,8),shorts,0,.76,0).scale.set(1,.7,.8);
  piece(new THREE.CylinderGeometry(.09,.10,.12,8),skin,0,1.46,0);
  const head=piece(new THREE.SphereGeometry(.18,14,12),skin,0,1.66,0);head.scale.set(1,1.16,.96);head.castShadow=true;
  const cap=piece(new THREE.SphereGeometry(.184,12,10,0,Math.PI*2,0,Math.PI*.52),hair,0,1.7,0);cap.scale.y=1.03;
  if(a.accessory==='headband')piece(new THREE.CylinderGeometry(.184,.184,.055,16),shoe,0,1.73,0);
  if(a.accessory==='cap'){piece(new THREE.SphereGeometry(.2,12,8,0,Math.PI*2,0,Math.PI*.5),shirt,0,1.74,0);piece(new THREE.BoxGeometry(.32,.025,.24),shirt,0,1.75,.17);}
  // Small face features stay readable at close camera distances.
  for(const x of [-.065,.065])piece(new THREE.SphereGeometry(.018,6,6),mat(0x242b2a),x,1.69,.16);piece(new THREE.SphereGeometry(.035,6,6),skin,0,1.63,.18);
  const limb=(x,y,m,len,radius)=>{const pivot=new THREE.Group();pivot.position.set(x,y,0);body.add(pivot);const mesh=piece(new THREE.CylinderGeometry(radius,radius*.85,len,8),m,0,-len/2,0,pivot);mesh.castShadow=true;return pivot;};
  const legs=[limb(-.13,.76,skin,.65,.095),limb(.13,.76,skin,.65,.095)];legs.forEach(l=>{piece(new THREE.CylinderGeometry(.103,.10,.18,8),shorts,0,-.08,0,l);piece(new THREE.CylinderGeometry(.084,.08,.16,8),shoe,0,-.55,0,l);const foot=piece(new THREE.BoxGeometry(.18,.13,.33),shoe,0,-.67,.07,l);foot.castShadow=true;});
  const arms=[limb(-.28,1.36,skin,.52,.075),limb(.28,1.36,skin,.52,.075)];arms.forEach(l=>piece(new THREE.CylinderGeometry(.095,.08,.18,8),shirt,0,-.07,0,l));
  const racket=new THREE.Group();racket.position.set(0,-.48,0);arms[1].add(racket);piece(new THREE.CylinderGeometry(.025,.028,.32,8),mat(0xe6e2d7),0,-.13,0,racket);
  const hoop=piece(new THREE.TorusGeometry(.2,.019,7,30),mat(a.racket),0,-.46,0,racket);hoop.scale.y=1.35;
  const stringMat=new THREE.LineBasicMaterial({color:0xdce4da,transparent:true,opacity:.65});for(let i=-4;i<=4;i++){const offset=i*.038,reach=Math.sqrt(.19*.19-offset*offset);for(const dir of [0,1]){const points=dir?[new THREE.Vector3(offset,-.46-reach*1.3,0),new THREE.Vector3(offset,-.46+reach*1.3,0)]:[new THREE.Vector3(-reach,-.46+offset*1.3,0),new THREE.Vector3(reach,-.46+offset*1.3,0)];racket.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),stringMat));}}
  const ring=piece(new THREE.RingGeometry(.4,.435,40),new THREE.MeshBasicMaterial({color:0xdbf78b,side:THREE.DoubleSide,transparent:true,opacity:.7}),0,.04,0,root);ring.rotation.x=-Math.PI/2;
  return {root,body,arms,legs,racket,ring};
 }
 disposeTree(root){const geometries=new Set(),materials=new Set(),textures=new Set();root.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)for(const m of Array.isArray(o.material)?o.material:[o.material]){materials.add(m);if(m.map&&m.map!==this.texture)textures.add(m.map);}});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());textures.forEach(t=>t.dispose());}
 setPlayers(players,appearance){for(const p of this.players){this.scene.remove(p.root);this.disposeTree(p.root);}this.players=players.map((p,i)=>{const a=i===0?appearance:{...appearance,shirt:p.team?'#f5eee0':'#d7ed71',shorts:p.team?'#263f47':'#f4f0e5',skin:i%2?'#b88566':'#77513b',hair:'#2c251f',racket:'#f08f68'};const m=this.createPlayer(a);m.ring.visible=i===0;this.scene.add(m.root);return m;});}
 setSurface(key){if(key!==this.surface){this.surface=key;this.disposeTree(this.world);this.buildCourt();}}
 puff(x,z,color=0xe1d2b3,count=8){for(let i=0;i<count;i++){const m=new THREE.Mesh(new THREE.BoxGeometry(.045,.045,.045),new THREE.MeshBasicMaterial({color,transparent:true}));m.position.set(x,.05,z);this.scene.add(m);this.effects.push({m,v:new THREE.Vector3((Math.random()-.5)*2,Math.random()*1.5,(Math.random()-.5)*2),life:.6});}}
 celebrate(){for(let i=0;i<120;i++){const m=new THREE.Mesh(new THREE.PlaneGeometry(.10,.22),new THREE.MeshBasicMaterial({color:[0xc8f36a,0xf4cd6a,0xffffff][i%3],side:THREE.DoubleSide}));m.position.set((Math.random()-.5)*18,7+Math.random()*10,(Math.random()-.5)*25);this.scene.add(m);this.effects.push({m,v:new THREE.Vector3((Math.random()-.5)*2,-1.5-Math.random()*2,(Math.random()-.5)*2),life:8});}}
 update(dt,game,menu=false){
  this.time+=game.paused&&!menu?0:dt;const b=game.ball;this.ball.visible=game.state!=='serve'||game.score.server===0;this.ball.position.set(b.x,b.y,b.z);this.ball.rotation.x+=dt*8;this.ballShadow.visible=b.live;this.ballShadow.position.set(b.x,.055,b.z);this.ballShadow.scale.setScalar(1+b.y*.18);this.ballShadow.material.opacity=clamp(.4-b.y*.035,.1,.4);
  const theme=game.store.data.stadium==='club'?game.store.data.appearance.shirt:'#102f36';if(this.stadiumTheme!==theme){this.stadiumTheme=theme;this.world.traverse(o=>{if(o.userData.board){o.material.map.dispose();o.material.map=this.textTexture(o.userData.label,'#edf0e4',theme);o.material.needsUpdate=true;}});}
  for(let i=this.trail.length-1;i>0;i--)this.trail[i].position.copy(this.trail[i-1].position);this.trail[0].position.copy(this.ball.position);for(const m of this.trail)m.visible=b.live;
  this.marker.visible=b.live&&this.settings.assist&&game.prediction; if(game.prediction)this.marker.position.set(game.prediction.x,.065,game.prediction.z);
  this.target.visible=!!game.target;if(game.target){this.target.position.set(game.target.x,.07,game.target.z);this.target.rotation.y=this.time*.4;this.target.scale.setScalar(game.options.drill==='movement'?1:game.options.drill==='accuracy'?2/.68:1.3/.68);}
  game.players.forEach((p,i)=>{const m=this.players[i];if(!m)return;m.root.position.set(p.x,0,p.z);m.root.rotation.y=p.team===0?Math.PI:0;const run=Math.min(1,Math.hypot(p.vx,p.vz)/4),phase=this.time*12;
   m.body.position.y=Math.abs(Math.sin(phase))*run*.045;m.body.rotation.z=-p.vx*.018;m.body.rotation.x=run*.06;
   m.legs[0].rotation.x=Math.sin(phase)*run*.65;m.legs[1].rotation.x=-Math.sin(phase)*run*.65;
   m.arms[0].rotation.x=-.2-Math.sin(phase)*run*.4;m.arms[1].rotation.x=-.25+Math.sin(phase)*run*.4;
   m.arms[1].rotation.z=-.2;m.arms[0].rotation.z=.16;m.body.rotation.y=0;
   if(p.swing>0){const k=1-p.swing/.48,backhand=game.ball.x<p.x;m.arms[1].rotation.x=p.shot==='smash'||p.shot==='serve'?-2.7+Math.sin(k*Math.PI)*2.8:-.5-Math.sin(k*Math.PI)*1.7;m.arms[1].rotation.z=backhand?.6+Math.sin(k*Math.PI)*1.2:-.3-Math.sin(k*Math.PI)*1.1;m.body.rotation.y=Math.sin(k*Math.PI*2)*.45*(backhand?-1:1);m.arms[0].rotation.x=backhand?-1.4:-.7;}
   if(game.state==='toss'&&game.serverPlayer===p){m.arms[0].rotation.x=-2.8;m.arms[1].rotation.x=-2.6;}
   if(game.state==='finished'&&game.score.winner===p.team){m.arms[0].rotation.z=2.5;m.arms[1].rotation.z=-2.5;m.body.position.y=Math.abs(Math.sin(this.time*5))*.15;if(p.id===0&&game.store.data.appearance.celebration==='salute'){m.arms[0].rotation.z=.1;m.arms[1].rotation.x=-2.6;m.arms[1].rotation.z=-.8;m.body.position.y=0;}}
   if(game.state==='point'&&game.lastPointWinner!==undefined&&game.lastPointWinner!==p.team){m.body.rotation.x=.12;m.arms[1].rotation.x=.15;}
   const dive=divePose(p);
   if(dive){
    const facing=p.team===0?-1:1;
    const direction=new THREE.Vector3(p.diveX*facing*Math.sin(dive.tilt),Math.cos(dive.tilt),p.diveZ*facing*Math.sin(dive.tilt));
    m.body.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),direction.normalize());
    m.body.position.y=dive.height;
    m.arms[1].rotation.set(-2.85*dive.stretch,0,-.12);
    m.arms[0].rotation.set(-1.95*dive.stretch,0,.65*dive.stretch);
    m.legs[0].rotation.x=-.5*dive.stretch;m.legs[1].rotation.x=.18*dive.stretch;
   }
   m.ring.material.color.set(p.diveTime>0?0xffffff:p.diveCooldown>0?0x91aa8b:0xdbf78b);
  });
  const cam=new THREE.Vector3(),look=new THREE.Vector3();if(menu){cam.set(24+Math.sin(this.time*.06)*2,22,29);look.set(-1,0,0);}else{const wide=this.camera.aspect<1.4?1.18:1;cam.set(clamp(b.x*.13,-1.5,1.5),(this.settings.camera==='close'?19:24)*wide,(this.settings.camera==='close'?29:32)*wide);look.set(b.x*.08,.5,-.6+clamp(b.z*.04,-.6,.6));}
  this.camera.position.lerp(cam,1-Math.exp(-dt*2));this.look.lerp(look,1-Math.exp(-dt*2));this.camera.lookAt(this.look);
  for(let i=this.effects.length-1;i>=0;i--){const e=this.effects[i];e.life-=dt;e.m.position.addScaledVector(e.v,dt);e.m.rotation.x+=dt*3;e.m.rotation.z+=dt*2;if(e.m.material.transparent)e.m.material.opacity=Math.min(1,e.life*2);if(e.life<=0){this.scene.remove(e.m);e.m.geometry.dispose();e.m.material.dispose();this.effects.splice(i,1);}}
  this.crowd.position.y=game.state==='point'?Math.sin(this.time*10)*.035:0;this.renderer.render(this.scene,this.camera);
 }
 quality(){const high=this.settings.quality==='high';this.renderer.setPixelRatio(Math.min(devicePixelRatio,high?1.8:1));this.renderer.shadowMap.enabled=high;this.resize();}
}
