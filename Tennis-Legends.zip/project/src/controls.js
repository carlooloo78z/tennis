export const CONTROLS_VERSION=2;
export const DEFAULT_KEYS={
  up:'KeyW',down:'KeyS',left:'KeyA',right:'KeyD',
  sprint:'ShiftLeft',dive:'KeyX',
  topspin:'KeyQ',slice:'KeyE',flat:'KeyF',lob:'KeyR',smash:'KeyC',serve:'Space'
};
export const LEGACY_KEYS={up:'KeyW',down:'KeyS',left:'KeyA',right:'KeyD',sprint:'Space',topspin:'KeyJ',slice:'KeyK',flat:'KeyL',lob:'KeyI',smash:'KeyU',serve:'Enter'};
export const PLAYER_TWO_KEYS={Numpad1:'topspin',Numpad2:'slice',Numpad3:'flat',Numpad5:'lob',Numpad4:'smash',NumpadEnter:'serve',Numpad0:'dive',Slash:'topspin',Period:'slice',Comma:'flat',Quote:'lob',Semicolon:'smash',ShiftRight:'serve',Backslash:'dive'};

// Upgrade the original layout without overwriting a player's custom bindings.
export function migrateControls(settings={}){
  if(settings.controlsVersion>=CONTROLS_VERSION)return {keys:{...DEFAULT_KEYS,...settings.keys},changed:false};
  const keys=settings.keys||{};
  const usedDefaults=Object.entries(LEGACY_KEYS).every(([action,key])=>!keys[action]||keys[action]===key);
  if(usedDefaults)return {keys:{...DEFAULT_KEYS},changed:true};
  const custom={...LEGACY_KEYS,...keys};
  if(!custom.dive)custom.dive=['KeyX','KeyV','KeyB',...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map(letter=>'Key'+letter)].find(key=>!Object.values(custom).includes(key));
  return {keys:custom,changed:false};
}
