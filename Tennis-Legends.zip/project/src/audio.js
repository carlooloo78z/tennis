export class StadiumAudio {
 constructor(settings){this.settings=settings;this.ctx=null;this.lastStep=0;}
 unlock(){try{if(!this.ctx){this.ctx=new (window.AudioContext||window.webkitAudioContext)();const c=this.ctx,buffer=c.createBuffer(1,c.sampleRate*3,c.sampleRate),data=buffer.getChannelData(0);let last=0;for(let i=0;i<data.length;i++){last=(last+(Math.random()*2-1)*.06)/1.06;data[i]=last;}const source=c.createBufferSource();source.buffer=buffer;source.loop=true;this.ambience=c.createGain();this.ambience.gain.value=.016*this.settings.volume;source.connect(this.ambience).connect(c.destination);source.start();}this.ctx.resume();}catch{}}
 update(active=true){if(this.ambience)this.ambience.gain.setTargetAtTime(this.settings.volume*(active?.026:.008),this.ctx.currentTime,.3);}
 tone(freq,duration=.1,type='sine',volume=.2,slide=0){if(!this.ctx||!this.settings.volume)return;const t=this.ctx.currentTime,o=this.ctx.createOscillator(),g=this.ctx.createGain();o.type=type;o.frequency.setValueAtTime(freq,t);if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(30,freq+slide),t+duration);g.gain.setValueAtTime(volume*this.settings.volume,t);g.gain.exponentialRampToValueAtTime(.001,t+duration);o.connect(g).connect(this.ctx.destination);o.start();o.stop(t+duration);}
 noise(duration,volume,filter=1600){if(!this.ctx||!this.settings.volume)return;const c=this.ctx,b=c.createBuffer(1,c.sampleRate*duration,c.sampleRate),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/d.length,1.4);const s=c.createBufferSource(),g=c.createGain(),f=c.createBiquadFilter();s.buffer=b;f.type='lowpass';f.frequency.value=filter;g.gain.value=volume*this.settings.volume;s.connect(f).connect(g).connect(c.destination);s.start();}
 hit(type){this.tone(type==='smash'?240:390,.09,'triangle',.3,-180);this.noise(.07,.22,2500);}
 bounce(){this.tone(175,.065,'sine',.18,-70);this.noise(.04,.06,900);}
 net(){this.noise(.23,.12,700);}
 dive(){this.noise(.18,.075,2200);}
 diveLanding(){this.tone(95,.12,'sine',.1,-45);this.noise(.24,.13,950);}
 crowd(big=false){this.noise(big?2.8:1.1,big?.3:.14,1800);for(let i=0;i<(big?12:5);i++)setTimeout(()=>this.noise(.08,.08,3500),i*87);}
 click(){this.tone(720,.055,'sine',.08,210);}
 step(){if(performance.now()-this.lastStep<280)return;this.lastStep=performance.now();this.noise(.045,.035,600);}
 victory(){[392,494,587,784,659,784,988].forEach((n,i)=>setTimeout(()=>this.tone(n,.5,'triangle',.12),i*180));this.crowd(true);}
 say(text){if(!this.settings.announcer||!this.settings.volume||!('speechSynthesis'in window))return;window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.rate=.94;u.volume=this.settings.volume*.7;window.speechSynthesis.speak(u);}
}
