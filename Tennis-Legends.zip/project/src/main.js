import {SaveStore} from './save.js';
import {StadiumAudio} from './audio.js';
import {TennisGame} from './game.js';
import {GameUI} from './ui.js';
import {PLAYER_TWO_KEYS} from './controls.js';
async function boot(){
 let scene,ui;
 const store=new SaveStore(),audio=new StadiumAudio(store.data.settings);
 try{const {CourtScene}=await import('./scene.js');scene=new CourtScene(document.querySelector('#court'),store.data.settings);}catch(error){document.querySelector('#loading').innerHTML='<div class="error-box"><h2>The court could not load</h2><p>This game needs WebGL 2. Try Chrome or Edge with hardware acceleration enabled, then reload. All game assets are included locally.</p><p id="error-detail"></p><button class="btn primary" onclick="location.reload()">Try again</button></div>';document.querySelector('#error-detail').textContent=error.message;console.error(error);return;}
 const game=new TennisGame(store,audio,{reset:()=>{},score:()=>ui?.updateScore(),state:()=>ui?.state(),shot:d=>ui?.shot(d),message:d=>ui?.message(d),finished:()=>ui?.finish(),puff:p=>scene.puff(p.x,p.z,game.options.court==='clay'?0xd69769:0xc3d3b7)});
 scene.setPlayers(game.players,store.data.appearance);ui=new GameUI(game,scene,store,audio);scene.quality();document.querySelector('#loading').remove();if(store.warning)ui.toast(store.warning);else if(store.controlsUpdated)ui.toast('Compact controls enabled. X dives, Shift sprints, Space serves. Press H in a match for the guide.');
 let last=performance.now(),accumulator=0,lastUI=0;
 scene.renderer.setAnimationLoop(now=>{const dt=Math.min((now-last)/1000,.05);last=now;accumulator+=dt;while(accumulator>=1/120){game.update(1/120);accumulator-=1/120;}scene.update(dt,game,!ui.inGame);if(now-lastUI>75){ui.tick();audio.update(ui.inGame&&!game.paused);lastUI=now;}});
 addEventListener('keydown',e=>{if(ui.captureBinding(e.code)){e.preventDefault();return;}if(['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName))return;audio.unlock();if(ui.inGame){if(e.repeat)return;if(e.code==='Escape'||e.code==='KeyP'){if(game.paused)ui.resume();else ui.pause();return;}if(e.code==='KeyH'){ui.help();return;}if(e.code==='F11'){e.preventDefault();ui.action('fullscreen');return;}if(game.paused)return;if([...Object.values(store.data.settings.keys),'ArrowUp','ArrowDown','ArrowLeft','ArrowRight','ControlRight',...Object.keys(PLAYER_TWO_KEYS)].includes(e.code))e.preventDefault();game.input(e.code,true);}});
 addEventListener('keyup',e=>game.input(e.code,false));addEventListener('blur',()=>{game.keys.clear();if(ui.inGame&&!game.paused)ui.pause();});document.addEventListener('visibilitychange',()=>{if(document.hidden&&ui.inGame&&!game.paused)ui.pause();});
 // A read-only inspection surface for QA and local debugging.
 window.tennisLegends={game,ui,scene,store};
}
boot().catch(error=>{console.error(error);const node=document.querySelector('#loading');if(node){node.textContent='Unable to start the game: '+error.message;}});
