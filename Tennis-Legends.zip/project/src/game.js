import {TennisScore} from './rules.js';
import {COURT,SURFACES,SHOTS,newBall,integrate,launch,predict,clamp,length} from './physics.js';
import {PLAYER_TWO_KEYS} from './controls.js';
import {DIVE} from './dive.js';
export {DIVE} from './dive.js';
export const OPPONENTS=[
 {name:'Luca Moretti',country:'ITA',style:'All-court',color:'#f5eee0'},
 {name:'Rafael Vega',country:'ESP',style:'Defensive',color:'#edb578'},
 {name:'Theo Laurent',country:'FRA',style:'Serve & volley',color:'#f4f1e8'},
 {name:'Noah Sterling',country:'GBR',style:'Power server',color:'#f0ece2'},
 {name:'Kai Nakamura',country:'JPN',style:'Aggressive',color:'#e8cbb8'},
 {name:'Mateo Silva',country:'BRA',style:'All-court',color:'#b0d1c1'},
 {name:'Elias Berg',country:'SWE',style:'Defensive',color:'#e5dfb2'}
];
const DIFFICULTY={rookie:{speed:4.2,error:1.0,reaction:.3,reach:1.25},club:{speed:5.3,error:.55,reaction:.19,reach:1.45},pro:{speed:6.4,error:.32,reaction:.11,reach:1.55},legend:{speed:7.4,error:.16,reaction:.06,reach:1.65}};
export class TennisGame {
 constructor(store,audio,events={}){this.store=store;this.audio=audio;this.events=events;this.keys=new Set();this.pending=[null,null];this.options={court:'hard',difficulty:'club',bestOf:1,doubles:false,local:false,mode:'exhibition',opponent:0};this.ball=newBall();this.score=new TennisScore();this.players=[];this.state='serve';this.paused=true;this.elapsed=0;this.prediction=null;this.target=null;this.reset(this.options,true);}
 emit(type,data){this.events[type]?.(data);}
 reset(options={},demo=false){
  this.options={...this.options,...options};this.surface=SURFACES[this.options.court];this.difficulty=DIFFICULTY[this.options.difficulty];this.opponent=OPPONENTS[this.options.opponent%OPPONENTS.length];this.score=new TennisScore(Number(this.options.bestOf),this.options.short?3:6);this.ball=newBall();this.elapsed=0;this.rally=0;this.bestRally=0;this.stats={winners:[0,0],aces:[0,0],faults:[0,0],shots:[0,0],distance:0,topSpeed:0};this.keys.clear();this.pending=[null,null];this.players=[this.player(0,0),this.player(1,1)];if(this.options.doubles)this.players.push(this.player(2,0),this.player(3,1));this.paused=demo;this.demo=demo;this.practice={attempts:0,hits:0,streak:0,best:0,remaining:90,done:false};this.target=null;this.prediction=null;this.faults=0;this.averageX=0;this.preparePoint();this.emit('reset',this);if(this.options.mode==='practice'){this.setupPractice();}this.emit('score',this);
 }
 player(id,team){return{id,team,x:0,z:team?-10.7:10.7,vx:0,vz:0,stamina:1,swing:0,shot:'topspin',cooldown:0,reaction:0,diveTime:0,diveRecovery:0,diveCooldown:0,diveX:0,diveZ:team?1:-1,human:id===0||(id===1&&this.options.local)};}
 get serverPlayer(){const team=this.score.server;if(!this.options.doubles)return this.players[team];const games=this.score.history.reduce((n,s)=>n+s[0]+s[1],0)+this.score.games[0]+this.score.games[1];const n=this.score.points[0]+this.score.points[1],turn=this.score.tie?(n===0?0:Math.floor((n-1)/2)+1):0;return this.players[(games+turn)%4];}
 preparePoint(keepFault=false){
  if(!keepFault)this.faults=0;this.rally=0;this.ball.live=false;this.state='serve';this.stateTime=0;this.pending=[null,null];
  const server=this.serverPlayer,side=this.score.deuceSide?1:-1;
  this.players.forEach(p=>{const sign=p.team?-1:1,serving=p===server,sameTeam=p.team===server.team,receiver=!sameTeam&&(!this.options.doubles||p.id===(this.score.deuceSide?p.team:p.team+2));p.x=serving?side*1.5*sign:receiver?side*2.1*sign:-side*2.5*sign;p.z=sign*(serving?12.35:receiver?10.3:3.8);p.vx=p.vz=0;p.cooldown=0;p.diveTime=p.diveRecovery=p.diveCooldown=0;});
  this.ball.x=server.x;this.ball.z=server.z;this.ball.y=1.15;this.ball.vx=this.ball.vy=this.ball.vz=0;this.ball.lastHit=server.team;this.ball.serving=false;this.prediction=null;this.emit('state',this);
 }
 setupPractice(){const drill=this.options.drill;this.target=null;if(drill==='movement'){this.state='drill';this.randomTarget(true);}else if(drill!=='serve'){this.feedTimer=1;this.state='feed';}this.emit('state',this);}
 randomTarget(near=false){this.target=near?{x:(Math.random()-.5)*6,z:3+Math.random()*9}:{x:[-3.2,0,3.2][Math.floor(Math.random()*3)],z:[-5.7,-9,-10.5][Math.floor(Math.random()*3)]};}
 input(code,down){if(down)this.keys.add(code);else this.keys.delete(code);if(!down||this.paused)return;
  const k=this.store.data.settings.keys;let team=0,action=Object.keys(k).find(a=>k[a]===code);
  const p2=PLAYER_TWO_KEYS;
  if(this.options.local&&p2[code]){team=1;action=p2[code];}
  if(action==='serve'&&this.score.server===team){if(this.state==='serve')this.toss();else if(this.state==='toss')this.strikeServe();}
  if(action==='dive')this.startDive(this.players.find(p=>p.team===team&&p.human));
  if(SHOTS[action]){this.pending[team]={shot:action,key:code,time:.7,held:0};if(this.state==='serve'&&this.score.server===team)this.toss();}
 }
 startDive(p){
  if(!p||this.paused||this.state!=='rally'||!this.ball.live||p.diveTime>0||p.diveRecovery>0||p.diveCooldown>0||p.stamina<DIVE.staminaCost)return false;
  let {x,z}=this.aim(p.team);
  if(Math.hypot(x,z)<.1){x=this.ball.x+this.ball.vx*.12-p.x;z=this.ball.z+this.ball.vz*.12-p.z;}
  const distance=Math.hypot(x,z);
  if(distance<.05){x=0;z=p.team?1:-1;}else{x/=distance;z/=distance;}
  p.diveX=x;p.diveZ=z;p.diveTime=DIVE.duration;p.diveRecovery=0;p.diveCooldown=DIVE.cooldown;
  p.stamina-=DIVE.staminaCost;p.swing=0;this.audio.dive();return true;
 }
 updateDive(p,dt){
  p.diveCooldown=Math.max(0,p.diveCooldown-dt);
  if(p.diveTime>0){
   const step=Math.min(dt,p.diveTime),speed=DIVE.speed*(.35+.65*p.diveTime/DIVE.duration);
   p.vx=p.diveX*speed;p.vz=p.diveZ*speed;p.diveTime=Math.max(0,p.diveTime-dt);
   this.translatePlayer(p,step);
   if(p.diveTime===0){p.diveRecovery=DIVE.recovery;p.vx*=.3;p.vz*=.3;this.emit('puff',{x:p.x,z:p.z});this.audio.diveLanding();}
  }else if(p.diveRecovery>0){
   p.diveRecovery=Math.max(0,p.diveRecovery-dt);const friction=Math.exp(-dt*14);
   p.vx*=friction;p.vz*=friction;this.translatePlayer(p,dt);p.stamina=Math.min(1,p.stamina+dt*.08);
   if(p.diveRecovery===0)p.vx=p.vz=0;
  }
 }
 translatePlayer(p,dt){
  const oldX=p.x,oldZ=p.z;p.x=clamp(p.x+p.vx*dt,-7.4,7.4);p.z=clamp(p.z+p.vz*dt,p.team?-15:.7,p.team?-.7:15);
  if(p.id===0)this.stats.distance+=Math.hypot(p.x-oldX,p.z-oldZ);
 }
 toss(){if(this.state!=='serve')return;this.state='toss';this.stateTime=0;this.ball.y=1.65;this.ball.vy=6.4;this.ball.live=false;this.emit('state',this);}
 strikeServe(auto=false){
  if(this.state!=='toss')return;const p=this.serverPlayer;const height=this.ball.y;const quality=clamp(1-Math.abs(height-3.45)/2,.12,1);const sign=p.team?-1:1;const deuce=this.score.deuceSide?1:-1;
  const aim=this.aim(p.team),err=(Math.random()-.5)*(auto?this.difficulty.error:.9)*(1-quality);
  const target={x:-deuce*sign*(2.0+aim.x*.75)+err,z:-sign*(4.4+aim.z*.6)};
  if(!auto&&quality<.35)target.z=-sign*7.5;
  this.ball.lastHit=p.team;const pace=auto&&this.opponent.style==='Power server'?quality*1.32:quality;
  const speed=launch(this.ball,target,'flat',pace,true);this.state='rally';this.stateTime=0;this.ball.serving=true;this.ball.bounces=0;p.swing=.48;p.shot='serve';this.rally=1;this.stats.shots[p.team]++;this.stats.topSpeed=Math.max(this.stats.topSpeed,speed);this.audio.hit('smash');this.emit('shot',{name:quality>.85?'PERFECT SERVE':'SERVE',speed,quality});this.prediction=predict(this.ball,this.surface);this.players.forEach(q=>q.reaction=this.difficulty.reaction);
 }
 aim(team){const k=this.store.data.settings.keys;const map=team?{left:'ArrowLeft',right:'ArrowRight',up:'ArrowUp',down:'ArrowDown'}:k;return{x:(this.keys.has(map.right)?1:0)-(this.keys.has(map.left)?1:0),z:(this.keys.has(map.down)?1:0)-(this.keys.has(map.up)?1:0)};}
 hit(p,shot,auto=false){
  const b=this.ball,diving=p.diveTime>0;if(!b.live||b.lastHit===p.team||p.cooldown>0||p.diveRecovery>0)return false;
  if(b.serving&&b.bounces===0)return false;
  if(diving){if(DIVE.duration-p.diveTime<.06||p.diveTime<.025||(b.x-p.x)*p.diveX+(b.z-p.z)*p.diveZ<-.15)return false;shot='slice';}
  const dist=length(b,p),reach=diving?DIVE.reach:p.human?(this.store.data.settings.assist?1.9:1.45):this.difficulty.reach;
  if(dist>reach||b.y<(diving?.06:.18)||b.y>(diving?1.5:3.4)||(shot==='smash'&&b.y<1.65))return false;
  const career=this.options.mode==='career'&&p.id===0;
  const quality=clamp(1-dist/(reach*1.7)-Math.abs(b.y-1.15)*.09+(career?this.store.data.attributes.control*.025:0),.2,diving?.6:1);const a=this.aim(p.team);const sign=p.team?-1:1;
  let tx,tz;const width=this.options.doubles?4.65:3.45;
  if(auto){const opponent=this.players.find(q=>q.team!==p.team),style=this.opponent.style,habit=p.team===1?this.averageX*.3:0;tx=(opponent.x+habit>0?-1:1)*(style==='Defensive'?2.2:width-.4);if(Math.random()<.25)tx=(Math.random()-.5)*5;tz=-sign*(style==='Serve & volley'?7.6:9.4);if(shot==='lob')tz=-sign*10.3;
   const error=this.difficulty.error*(1.2-quality);tx+=(Math.random()-.5)*error*3;tz+=(Math.random()-.5)*error*3;
   const missChance=(this.options.difficulty==='rookie'?.065:.018)+Math.min(.045,this.rally*.0018);
   if(Math.random()<missChance){tx=Math.sign(tx||1)*(width+1.25);}
   if(this.options.mode==='practice'){tx=clamp(opponent.x*.55,-2,2);tz=-sign*8.4;}
  }else{tx=a.x? a.x*width:clamp(-p.x*.5,-2.4,2.4);tz=-sign*(a.z===-sign?10.8:a.z===sign?5.7:9);const error=(1-quality)*(this.store.data.settings.assist?.35:1.3);tx+=(Math.random()-.5)*error;tz+=(Math.random()-.5)*error;}
  if(shot==='smash')tz=-sign*7.6;
  const volley=b.bounces===0,power=diving?.18:auto?quality:clamp(.35+(this.pending[p.team]?.held||0)*.55+(career?this.store.data.attributes.power*.035:0),.3,1);
  const speed=launch(b,{x:tx,z:tz},shot,power);b.lastHit=p.team;b.serving=false;p.cooldown=.35;p.swing=.48;p.shot=shot;this.pending[p.team]=null;this.rally++;this.bestRally=Math.max(this.bestRally,this.rally);this.stats.shots[p.team]++;this.stats.topSpeed=Math.max(this.stats.topSpeed,speed);this.audio.hit(shot);this.emit('shot',{name:diving?'DIVING SAVE':volley&&shot!=='smash'?'VOLLEY':SHOTS[shot].name,speed,quality});this.prediction=predict(b,this.surface);this.players.forEach(q=>q.reaction=this.difficulty.reaction);if(p.team===0)this.averageX=this.averageX*.8+p.x*.2;
  if(this.options.mode==='practice'&&['target','accuracy'].includes(this.options.drill))this.practice.attempts++;
  if(this.options.mode==='practice'&&this.options.drill==='rally'&&p.team===0){this.practice.hits++;this.practice.streak++;this.practice.best=Math.max(this.practice.best,this.practice.streak);}
  return true;
 }
 move(p,tx,tz,dt,sprint=false){if(p.diveTime>0||p.diveRecovery>0)return;const l=Math.hypot(tx,tz);if(l>1){tx/=l;tz/=l;}let speed=p.human?5.6:this.options.mode==='practice'?6.4:this.difficulty.speed;if(this.options.mode==='career'&&p.id===0)speed+=this.store.data.attributes.speed*.12;
  if(sprint&&p.stamina>.05){speed*=1.38;p.stamina=Math.max(0,p.stamina-dt*.22);}else p.stamina=Math.min(1,p.stamina+dt*.14);
  const blend=1-Math.exp(-dt*18);p.vx+=(tx*speed-p.vx)*blend;p.vz+=(tz*speed-p.vz)*blend;p.x=clamp(p.x+p.vx*dt,-7.4,7.4);p.z=clamp(p.z+p.vz*dt,p.team?-15:-.7,p.team?-.7:15);if(p.team===0){p.z=clamp(p.z,.7,15);this.stats.distance+=Math.hypot(p.vx,p.vz)*dt;if(l>.1)this.audio.step();}
 }
 ai(p,dt){
  const b=this.ball;let tx=p.id>1?(p.id===2?-2.6:2.6):0,tz=(p.team?-1:1)*(p.id>1?3.4:10.1);
  const incoming=b.live&&b.lastHit!==p.team;
  if(incoming){
   const pred=this.prediction??b;const sign=p.team?-1:1;
   tx=clamp(pred.x,-6,6);tz=clamp(pred.z+sign*1.8,p.team?-13:.8,p.team?-.8:13);
   if(b.bounces>0){tx=b.x+ b.vx*.12;tz=b.z+b.vz*.12;}
   if(this.options.doubles&&Math.abs(p.z)<6&&Math.abs(pred.z)>7){tz=sign*3.8;tx=clamp(b.x,-4.5,4.5);}
   if(this.opponent.style==='Serve & volley'&&!b.serving&&b.y<2.8&&Math.abs(b.z)<7){tx=b.x;tz=b.z;}
   if(p.reaction<=0){const dist=Math.hypot(tx-p.x,tz-p.z);this.move(p,dist>.15?(tx-p.x)/Math.max(.5,dist):0,dist>.15?(tz-p.z)/Math.max(.5,dist):0,dt,dist>5);}
   let shot=b.y>2?'smash':this.opponent.style==='Defensive'?(Math.random()<.5?'lob':'topspin'):this.opponent.style==='Aggressive'?'flat':Math.random()<.2?'slice':'topspin';
   if(this.options.mode==='practice')shot='topspin';this.hit(p,shot,true);
  }else {if(this.opponent.style==='Serve & volley'&&p.id===1)tz=-4.2;const d=Math.hypot(tx-p.x,tz-p.z);this.move(p,d>.3?(tx-p.x)/Math.max(d,1):0,d>.3?(tz-p.z)/Math.max(d,1):0,dt);}
 }
 fault(reason){this.faults++;this.stats.faults[this.score.server]++;this.audio.say(this.faults===2?'Double fault':'Fault');if(this.faults>=2)this.point(1-this.score.server,'DOUBLE FAULT');else{this.state='fault';this.stateTime=0;this.ball.live=false;this.emit('message',{title:'FAULT',sub:reason+' · Second serve'});}}
 point(winner,reason){if(['point','finished','fault'].includes(this.state))return;this.ball.live=false;this.stateTime=0;this.prediction=null;this.lastPointWinner=winner;
  if(this.options.mode==='practice'){
   if(this.options.drill==='serve'){this.practice.attempts++;if(winner===0){this.practice.hits++;this.practice.streak++;}else this.practice.streak=0;this.practice.best=Math.max(this.practice.best,this.practice.streak);}
   else if(winner===1)this.practice.streak=0;
   this.state='point';this.emit('message',{title:reason,sub:'Keep going · '+this.practice.hits+' successful shots'});return;
  }
  if(reason==='ACE')this.stats.aces[winner]++;else if(reason==='WINNER'||reason==='SECOND BOUNCE')this.stats.winners[winner]++;
  const event=this.score.point(winner);this.emit('score',this);this.audio.crowd(this.rally>=7||event.game!==undefined);
  this.state='point';const name=winner===0?this.store.data.name:this.options.local?'Player 2':this.opponent.name;
  let title=event.set!==undefined?'SET '+name.toUpperCase():event.game!==undefined?'GAME '+name.toUpperCase():reason;
  let sub=event.game!==undefined?`${this.score.games[0]}–${this.score.games[1]} games`:name+' wins the point';
  if(this.score.winner!==null){this.state='finished';for(const p of this.players){p.diveTime=p.diveRecovery=0;p.vx=p.vz=0;}this.audio.victory();this.emit('finished',this);}else{this.emit('message',{title,sub});const scores=this.score.display(),call=scores.includes('AD')?'Advantage, '+name:this.score.pressure()==='DEUCE'?'Deuce':[scores[this.score.server],scores[1-this.score.server]].map(n=>n==='0'?'love':n).join(', ');this.audio.say(event.game!==undefined?'Game, '+name:call);}
 }
 feed(){this.state='rally';this.ball={...newBall(),x:(Math.random()-.5)*4,y:1.6,z:-10,lastHit:1};launch(this.ball,{x:(Math.random()-.5)*4,z:8},'topspin',.4);this.ball.lastHit=1;this.prediction=predict(this.ball,this.surface);if(['target','accuracy'].includes(this.options.drill))this.randomTarget();}
 finishPractice(){if(this.practice.done)return;this.practice.done=true;this.state='finished';this.ball.live=false;this.emit('finished',this);this.audio.crowd(true);}
 update(dt){
  if(this.paused||this.state==='finished')return;this.elapsed+=dt;this.stateTime+=dt;
  if(this.options.mode==='practice'){this.practice.remaining-=dt;if(this.practice.remaining<=0){this.finishPractice();return;}}
  for(const p of this.players){p.swing=Math.max(0,p.swing-dt);p.cooldown=Math.max(0,p.cooldown-dt);p.reaction-=dt;this.updateDive(p,dt);if(this.state!=='rally'&&this.state!=='drill')p.stamina=Math.min(1,p.stamina+dt*.16);}
  for(let t=0;t<2;t++)if(this.pending[t]){const key=this.pending[t].key;if(this.keys.has(key)){this.pending[t].held+=dt;this.pending[t].time=.25;}else this.pending[t].time-=dt;if(this.pending[t].time<=0)this.pending[t]=null;}
  if(this.state==='point'){if(this.stateTime>2.3){this.preparePoint();if(this.options.mode==='practice')this.setupPractice();}return;}
  if(this.state==='fault'){if(this.stateTime>1.7)this.preparePoint(true);return;}
  if(this.state==='feed'){if(this.stateTime>1.2){this.feed();this.stateTime=0;}return;}
  if(this.state==='serve'){
   const p=this.serverPlayer;this.ball.x=p.x;this.ball.z=p.z;
   if(!p.human&&this.stateTime>1.1)this.toss();return;
  }
  if(this.state==='toss'){
   this.ball.vy-=9.81*dt;this.ball.y+=this.ball.vy*dt;
   if(!this.serverPlayer.human&&this.stateTime>.53)this.strikeServe(true);
   else if(this.stateTime>1.05)this.strikeServe(false);return;
  }
  for(const p of this.players){if(p.human){const a=this.aim(p.team),sprint=p.team?this.keys.has('ControlRight'):this.keys.has(this.store.data.settings.keys.sprint);this.move(p,a.x,a.z,dt,sprint);if(p.diveTime>0)this.hit(p,'slice');else if(this.pending[p.team])this.hit(p,this.pending[p.team].shot);else if(this.store.data.settings.assist&&this.options.mode!=='practice'&&this.ball.live&&this.ball.bounces>0&&length(this.ball,p)<1.12&&this.ball.y<1.65)this.hit(p,'topspin');}else if(!(this.options.mode==='practice'&&['target','accuracy','movement','serve'].includes(this.options.drill)))this.ai(p,dt);}
  if(this.state==='drill'){if(length(this.players[0],this.target)<.7){this.practice.hits++;this.audio.click();this.emit('puff',this.target);this.randomTarget(true);}return;}
  if(!this.ball.live)return;
  const b=this.ball,e=integrate(b,dt,this.surface);
  if(e.tape)this.audio.net();
  if(e.net){this.audio.net();if(b.serving)this.fault('Into the net');else this.point(1-b.lastHit,'NET');return;}
  if(e.bounce){this.audio.bounce();this.emit('puff',{x:b.x,z:b.z});const opposite=b.lastHit===0?b.z<0:b.z>0;const width=this.options.doubles?COURT.doublesWidth:COURT.halfWidth;
   if(b.bounces===1){
    if(b.serving){const server=this.serverPlayer;const correctX=Math.sign(b.x)===-Math.sign(server.x)||Math.abs(b.x)<=.034;if(!opposite||!correctX||Math.abs(b.x)>COURT.halfWidth+.034||Math.abs(b.z)>COURT.service+.034){this.fault('Outside the service box');return;}if(b.netTouch){this.state='fault';this.stateTime=0;b.live=false;this.emit('message',{title:'LET',sub:'Replay the serve'});return;}
      if(this.options.mode==='practice'&&this.options.drill==='serve'){this.point(0,'GOOD SERVE');return;}
    }else if(!opposite||Math.abs(b.x)>width+.034||Math.abs(b.z)>COURT.halfLength+.034){this.point(1-b.lastHit,'OUT');return;}
    if(this.options.mode==='practice'&&this.target&&b.lastHit===0){const d=length(b,this.target);const good=d<(this.options.drill==='accuracy'?2:1.3);if(good){this.practice.hits++;this.practice.streak++;this.audio.crowd();}else this.practice.streak=0;this.practice.best=Math.max(this.practice.best,this.practice.streak);this.point(good?0:1,good?'TARGET HIT':'KEEP AIMING');return;}
   }else{this.point(b.lastHit,b.serving?'ACE':'WINNER');return;}
  }
  if(Math.abs(b.x)>11||Math.abs(b.z)>22||b.y<-.5){this.point(b.bounces?b.lastHit:1-b.lastHit,b.bounces?'WINNER':'OUT');}
 }
}
