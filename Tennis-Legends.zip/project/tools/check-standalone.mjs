import assert from 'node:assert/strict';
import vm from 'node:vm';
import {standaloneHTML} from './build-standalone.mjs';

const html=await standaloneHTML();
const {imports}=JSON.parse(html.match(/<script type="importmap">([\s\S]*?)<\/script>/)[1]);
const context=vm.createContext({console,structuredClone,performance,AbortController,URL,Blob,setTimeout,clearTimeout});
const modules=new Map();
for(const [id,url] of Object.entries(imports)){
  assert.ok(url.startsWith('data:text/javascript;base64,'));
  const source=Buffer.from(url.split(',')[1],'base64').toString('utf8');
  modules.set(id,new vm.SourceTextModule(source,{context,identifier:id}));
}
const resolve=id=>{assert.ok(modules.has(id),'Embedded dependency missing: '+id);return modules.get(id);};
for(const module of modules.values())if(module.status==='unlinked')await module.link(resolve);
// Evaluate all non-entry modules and verify actual game behavior from the package.
for(const [id,module] of modules)if(!id.endsWith('/main.js')&&module.status!=='evaluated')await module.evaluate();
const {SaveStore}=modules.get('tennis/src/save.js').namespace;
const {TennisGame}=modules.get('tennis/src/game.js').namespace;
const storage={getItem:()=>null,setItem(){}};
const game=new TennisGame(new SaveStore(storage),new Proxy({},{get:()=>()=>{}}));
game.reset({court:'hard',mode:'exhibition',doubles:false});
game.state='rally';game.paused=false;game.ball.live=true;
game.input('KeyX',true);
assert.ok(game.players[0].diveTime>0,'Packaged game accepts the dive key');
for(let i=0;i<120;i++)game.update(1/120);
assert.ok(Number.isFinite(game.players[0].x));
assert.equal(modules.get('tennis/vendor/three.module.min.js').namespace.REVISION,'180');
assert.equal((html.match(/data:font\/ttf;base64,/g)||[]).length,2);
assert.ok(!/<(?:script|link)[^>]+(?:src|href)=/i.test(html),'No external scripts or styles');
JSON.parse(html.match(/id="third-party-licenses">([\s\S]*?)<\/script>/)[1]);
console.log(`PASS: all ${modules.size} embedded modules link; engine, gameplay, diving, fonts and licenses are present.`);
