import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {openBrowser} from './open-browser.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const port=process.env.PORT||'57123',url=`http://127.0.0.1:${port}`;
try{
  const response=await fetch(url+'/__health',{signal:AbortSignal.timeout(1200)});
  const health=await response.json();
  if(health.app==='tennis-legends'){
    console.log('Tennis Legends is already running at '+url);
    openBrowser(url);
    process.exitCode=0;
  }else await startServer();
}catch{await startServer();}

async function startServer(){
const server=spawn(process.execPath,[fileURLToPath(new URL('./serve.mjs',import.meta.url))],{cwd:root,env:{...process.env,PORT:port},windowsHide:true,stdio:['ignore','pipe','inherit']});
let opened=false;
server.stdout.on('data',data=>{const text=String(data);process.stdout.write(text);const address=text.match(/http:\/\/127\.0\.0\.1:\d+/)?.[0];if(address&&!opened){opened=true;console.log('Tennis Legends is ready. Keep this window open while playing.');openBrowser(address);}});
server.on('error',error=>{console.error('Could not start the game server:',error.message);process.exitCode=1;});
server.on('exit',code=>process.exit(code||0));process.on('SIGINT',()=>{server.kill();process.exit(0);});
}
