import {mkdir,cp} from 'node:fs/promises';
await mkdir('dist',{recursive:true});
await cp('index.html','dist/index.html');await cp('.nojekyll','dist/.nojekyll');await cp('src','dist/src',{recursive:true});await cp('vendor','dist/vendor',{recursive:true});
console.log('Built static game in dist/');
