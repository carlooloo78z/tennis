// Construct and animate the complete scene with real Three.js geometry and a
// stub GPU endpoint. This catches startup exceptions without claiming visual QA.
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import * as Three from '../vendor/three.module.min.js';
import * as Physics from '../src/physics.js';
import * as Dive from '../src/dive.js';
import {TennisGame} from '../src/game.js';
import {SaveStore} from '../src/save.js';

const context2D=new Proxy({},{get:()=>()=>{},set:()=>true});
const canvas=()=>({width:512,height:512,getContext:()=>context2D});
class TestRenderer {
  constructor(){this.shadowMap={};}
  setSize(){} setPixelRatio(){} render(){} setAnimationLoop(){}
}
const context=vm.createContext({console,Math,innerWidth:1440,innerHeight:900,devicePixelRatio:1,document:{createElement:canvas},addEventListener(){}});
function moduleFor(exports){const keys=Object.keys(exports);return new vm.SyntheticModule(keys,function(){for(const key of keys)this.setExport(key,exports[key]);},{context});}
const module=new vm.SourceTextModule(await readFile(new URL('../src/scene.js',import.meta.url),'utf8'),{context});
await module.link(specifier=>specifier==='three'?moduleFor({...Three,WebGLRenderer:TestRenderer}):specifier==='./dive.js'?moduleFor(Dive):moduleFor(Physics));
await module.evaluate();
const store=new SaveStore({getItem:()=>null,setItem(){}});
const audio=new Proxy({},{get:()=>()=>{}});
const game=new TennisGame(store,audio);
const scene=new module.namespace.CourtScene(canvas(),store.data.settings);
for(const court of Object.keys(Physics.SURFACES)){
  for(const doubles of [false,true]){
    game.reset({court,doubles});scene.setSurface(court);scene.setPlayers(game.players,store.data.appearance);
    for(const state of ['serve','toss','rally','point','finished']){game.state=state;scene.update(1/60,game,false);}
    for(const player of game.players){player.diveX=.8;player.diveZ=.6;for(const t of [.44,.3,.15,.01]){player.diveTime=t;scene.update(1/60,game,false);}player.diveTime=0;for(const t of [.5,.25,.01]){player.diveRecovery=t;scene.update(1/60,game,false);}player.diveRecovery=0;}
    console.log('Scene constructed and animated:',court,doubles?'doubles':'singles',scene.world.children.length,'stadium objects');
  }
}
