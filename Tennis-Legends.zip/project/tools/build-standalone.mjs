import {readFile,readdir,mkdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';

const projectRoot=fileURLToPath(new URL('../',import.meta.url));
const moduleId=file=>'tennis/'+file;

// Embed the existing ES modules without changing their scopes or exports.
// Import-map names give data modules stable identities and shared dependencies.
export async function standaloneHTML(root=projectRoot){
  const modules=[...(await readdir(path.join(root,'src'))).filter(name=>name.endsWith('.js')).map(name=>'src/'+name),
    'vendor/three.module.min.js','vendor/three.core.min.js'];
  const available=new Set(modules),imports={};
  for(const file of modules){
    let source=await readFile(path.join(root,file),'utf8');
    source=source.replace(/(\bfrom\s*|\bimport\s*\(\s*|\bimport\s*)(['"])(three|\.\.?\/[^'"\r\n]+)\2/g,(match,prefix,quote,specifier)=>{
      const target=specifier==='three'?'vendor/three.module.min.js':
        specifier.startsWith('.')?path.posix.normalize(path.posix.join(path.posix.dirname(file),specifier)):null;
      if(!target||!available.has(target))throw new Error(`Unbundled module in ${file}: ${specifier}`);
      return prefix+quote+moduleId(target)+quote;
    });
    imports[moduleId(file)]='data:text/javascript;base64,'+Buffer.from(source).toString('base64');
  }
  let css=await readFile(path.join(root,'src/style.css'),'utf8');
  for(const font of ['dm-sans.ttf','barlow-condensed.ttf']){
    const data=await readFile(path.join(root,'vendor',font));
    css=css.replaceAll('../vendor/'+font,'data:font/ttf;base64,'+data.toString('base64'));
  }
  if(/url\(\s*['"]?\.\.?\//.test(css))throw new Error('A stylesheet asset was not embedded');
  const licenses={};
  for(const name of ['THREE-LICENSE.txt','DM-SANS-LICENSE.txt','BARLOW-LICENSE.txt']){
    licenses[name]=await readFile(path.join(root,'vendor',name),'utf8');
  }
  let html=await readFile(path.join(root,'index.html'),'utf8');
  html=html.replace('<link rel="stylesheet" href="./src/style.css">',()=>'<style>'+css+'</style>');
  html=html.replace(/<script type="importmap">[\s\S]*?<\/script>/,()=>'<script type="importmap">'+JSON.stringify({imports})+'</script>');
  html=html.replace('<script type="module" src="./src/main.js"></script>',()=>`<script type="module">
import('tennis/src/main.js').catch(error=>{
  console.error(error);
  const loading=document.getElementById('loading');
  if(loading)loading.textContent='Unable to start Tennis Legends: '+error.message+'. Try the latest Chrome or Edge.';
});
</script>`);
  html=html.replace('</body>',()=>'<script type="application/json" id="third-party-licenses">'+JSON.stringify(licenses).replaceAll('<','\\u003c')+'</script></body>');
  if(/(?:src|href)="\.\//.test(html))throw new Error('The standalone page still has an external file dependency');
  return html;
}

if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){
  const output=path.resolve(process.argv[2]||path.join(projectRoot,'standalone/index.html'));
  await mkdir(path.dirname(output),{recursive:true});
  const html=await standaloneHTML();
  await writeFile(output,html);
  console.log(`Standalone game: ${output} (${Buffer.byteLength(html)} bytes; no external assets)`);
}
