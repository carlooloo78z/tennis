import {spawn} from 'node:child_process';
import path from 'node:path';

export function browserCommand(url,platform=process.platform,env=process.env){
  if(platform==='win32'){
    const command=env.ComSpec||env.COMSPEC||path.win32.join(env.SystemRoot||'C:\\Windows','System32','cmd.exe');
    return [command,['/d','/c','start','',url]];
  }
  return [platform==='darwin'?'open':'xdg-open',[url]];
}

export function openBrowser(url){
  const [command,args]=browserCommand(url);
  const browser=spawn(command,args,{windowsHide:true,stdio:'ignore'});
  browser.on('error',error=>console.log(`Automatic browser opening failed (${error.code}). Open ${url} manually. The game server is still running.`));
  browser.on('exit',code=>{if(code)console.log(`Open ${url} manually. The game server is still running.`);});
  return browser;
}
