import test from 'node:test';
import assert from 'node:assert/strict';
import {GameUI} from '../src/ui.js';
import {TennisGame} from '../src/game.js';
import {SaveStore} from '../src/save.js';
import {SURFACES} from '../src/physics.js';

function harness(){
 const store=new SaveStore({getItem:()=>null,setItem:()=>{}});
 const audio=new Proxy({},{get:()=>()=>{}});
 const game=new TennisGame(store,audio);
 const ui=Object.assign(Object.create(GameUI.prototype),{store,game,audio,scene:{celebrate(){}},setup:{court:'hard',difficulty:'club',bestOf:1,local:false,doubles:false,opponent:0},page:'home',inGame:true,resultRewarded:false,state(){},modal(){},render(){},toast(){}});
 return {store,game,ui};
}
test('tournament advances through a real draw, awards a trophy once and does not allow a result replay',()=>{
 const {store,game,ui}=harness();ui.newTournament();let lastCredits=store.data.credits;
 for(let round=0;round<3;round++){
  game.reset({mode:'tournament'});game.score.winner=0;game.score.history=[[6,3]];game.state='finished';ui.resultRewarded=false;ui.finish();
  assert.ok(store.data.credits>lastCredits);lastCredits=store.data.credits;ui.finish();assert.equal(store.data.credits,lastCredits);
  assert.equal(store.data.tournament.results[round][0],store.data.name);
  if(round<2){assert.equal(store.data.tournament.round,round+1);assert.equal(store.data.tournament.rounds[round+1].length,2/(round+1));}
 }
 assert.equal(store.data.tournament.won,true);assert.equal(store.data.trophies,1);assert.ok(store.data.achievements.includes('champion'));
});
test('losing a tournament match eliminates the player and keeps the draw',()=>{
 const {store,game,ui}=harness();ui.newTournament();game.reset({mode:'tournament'});game.score.winner=1;game.state='finished';ui.finish();assert.equal(store.data.tournament.eliminated,true);assert.equal(store.data.tournament.round,0);assert.equal(store.data.trophies,0);
});
test('all five training drills reward actual completed-session results',()=>{
 for(const drill of ['serve','rally','target','accuracy','movement']){const {store,game,ui}=harness();game.reset({mode:'practice',drill});game.practice.hits=7;game.state='finished';ui.finish();assert.equal(store.data.credits,376);assert.equal(store.data.xp,75);assert.equal(store.data.training,1);}
});
test('binding duplicates swap and reserved keys are preserved',()=>{
 const {store,ui}=harness();ui.rebinding='topspin';ui.captureBinding('KeyE');assert.equal(store.data.settings.keys.topspin,'KeyE');assert.equal(store.data.settings.keys.slice,'KeyQ');ui.rebinding='flat';ui.captureBinding('KeyP');assert.equal(store.data.settings.keys.flat,'KeyF');ui.captureBinding('Escape');assert.equal(ui.rebinding,null);
});
test('every menu renders and safely escapes the player name',()=>{
 const {store,ui}=harness();store.data.name='<img src=x>';for(const page of ['home','play','career','tournament','practice','customise','settings']){ui.page=page;const html=ui[page]();assert.ok(html.length>500,page);assert.equal(html.includes('<img src=x>'),false,page);}assert.ok(ui.header().includes('&lt;img'));
});
test('doubles tiebreak rotates through all four servers',()=>{
 const {game:g}=harness();g.reset({doubles:true});for(let game=0;game<12;game++)for(let point=0;point<4;point++)g.score.point(game%2);assert.equal(g.serverPlayer.id,0);g.score.point(0);assert.equal(g.serverPlayer.id,1);g.score.point(1);g.score.point(0);assert.equal(g.serverPlayer.id,2);g.score.point(1);g.score.point(0);assert.equal(g.serverPlayer.id,3);
});
test('a valid let preserves second serve and does not change score',()=>{
 const {game:g}=harness();g.reset();g.paused=false;g.state='rally';g.faults=1;g.ball={x:-2,z:-4,y:.04,vx:0,vy:-2,vz:-1,spin:0,curve:0,bounces:0,lastHit:0,serving:true,netTouch:true,live:true};g.update(1/120);assert.equal(g.state,'fault');assert.equal(g.faults,1);assert.equal(g.score.totalPoints,0);for(let n=0;n<220;n++)g.update(1/120);assert.equal(g.state,'serve');assert.equal(g.faults,1);
});
test('four courts and five AI styles remain finite through long simulated play',()=>{
 const original=Math.random;let seed=331;Math.random=()=>((seed=(seed*1664525+1013904223)>>>0)/4294967296);
 try{for(const court of Object.keys(SURFACES))for(let opponent=0;opponent<5;opponent++){const {game:g}=harness();g.reset({court,opponent,difficulty:'club'});g.paused=false;g.players.forEach(p=>p.human=false);for(let n=0;n<120*180;n++)g.update(1/120);assert.ok(g.score.totalPoints>0,court+' '+opponent);assert.ok(Number.isFinite(g.ball.x)&&Number.isFinite(g.ball.y)&&Number.isFinite(g.ball.z));assert.ok(g.stats.shots[0]>0&&g.stats.shots[1]>0);}}
 finally{Math.random=original;}
});
