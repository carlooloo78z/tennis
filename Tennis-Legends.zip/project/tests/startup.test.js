import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,stat} from 'node:fs/promises';
import {browserCommand} from '../tools/open-browser.mjs';

test('Windows browser launcher resolves cmd even when it is missing from PATH',()=>{
  const [command,args]=browserCommand('http://127.0.0.1:57123','win32',{SystemRoot:'C:\\WINDOWS',PATH:''});
  assert.equal(command,'C:\\WINDOWS\\System32\\cmd.exe');
  assert.deepEqual(args,['/d','/c','start','','http://127.0.0.1:57123']);
});

test('Windows browser launcher respects the configured command processor',()=>{
  assert.equal(browserCommand('http://localhost','win32',{ComSpec:'D:\\Windows\\System32\\cmd.exe'})[0],'D:\\Windows\\System32\\cmd.exe');
});

test('all startup dependencies are present locally',async()=>{
  const html=await readFile(new URL('../index.html',import.meta.url),'utf8');
  const css=await readFile(new URL('../src/style.css',import.meta.url),'utf8');
  assert.ok(html.includes('./vendor/three.module.min.js'));
  assert.ok(!html.includes('https://cdn.'));
  assert.ok(!css.includes('@import'));
  for(const file of ['three.module.min.js','three.core.min.js','dm-sans.ttf','barlow-condensed.ttf']){
    assert.ok((await stat(new URL('../vendor/'+file,import.meta.url))).size>10000,file);
  }
  const three=await import('../vendor/three.module.min.js');
  assert.equal(three.REVISION,'180');
  const scene=new three.Scene();scene.add(new three.Mesh(new three.BoxGeometry(),new three.MeshStandardMaterial()));
  assert.equal(scene.children.length,1);
});
