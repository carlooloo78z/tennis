import test from 'node:test';
import assert from 'node:assert/strict';
import {TennisGame,DIVE} from '../src/game.js';
import {SaveStore} from '../src/save.js';
import {DEFAULT_KEYS,LEGACY_KEYS} from '../src/controls.js';
import {divePose} from '../src/dive.js';

function fixture(options={}){
  const store=new SaveStore({getItem:()=>null,setItem(){}});
  const audio=new Proxy({},{get:()=>()=>{}}),shots=[];
  const game=new TennisGame(store,audio,{shot:data=>shots.push(data)});
  game.reset(options);game.paused=false;game.state='rally';
  Object.assign(game.players[0],{x:0,z:10});
  Object.assign(game.ball,{x:4,y:.45,z:10,vx:0,vy:0,vz:0,bounces:1,lastHit:1,live:true});
  return {game,player:game.players[0],store,shots};
}

test('a dive moves continuously and rescues a low ball outside normal reach',()=>{
  const {game:g,player:p,shots}=fixture();
  assert.equal(g.hit(p,'slice'),false);
  g.input('KeyD',true);g.input(DEFAULT_KEYS.dive,true);
  assert.equal(p.diveTime,DIVE.duration);
  assert.equal(p.x,0,'the launch must not teleport the player');
  assert.ok(p.stamina<1);
  let previous=p.x;
  for(let frame=0;frame<80&&g.ball.lastHit!==0;frame++){
    g.update(1/120);
    assert.ok(Math.abs(p.x-previous)<.12,'continuous lunge');previous=p.x;
  }
  assert.equal(g.ball.lastHit,0,'the stretched return should reach the ball');
  assert.equal(shots.at(-1).name,'DIVING SAVE');
  assert.ok(g.ball.live);
});

test('dive direction uses held movement or aims toward the ball when stationary',()=>{
  let {game:g,player:p}=fixture();g.input('KeyA',true);assert.equal(g.startDive(p),true);assert.equal(p.diveX,-1);
  ({game:g,player:p}=fixture());assert.equal(g.startDive(p),true);assert.equal(p.diveX,1);
  ({game:g,player:p}=fixture());g.input('KeyD',true);g.input('KeyW',true);g.startDive(p);assert.ok(Math.abs(Math.hypot(p.diveX,p.diveZ)-1)<1e-9);assert.ok(p.diveX>0&&p.diveZ<0);
});

test('dives require stamina, recover before another shot, and cannot be spammed',()=>{
  const {game:g,player:p}=fixture();p.stamina=.1;assert.equal(g.startDive(p),false);
  p.stamina=1;assert.equal(g.startDive(p),true);assert.equal(g.startDive(p),false);
  for(let n=0;n<54;n++)g.updateDive(p,1/120);
  assert.equal(p.diveTime,0);assert.ok(p.diveRecovery>0);
  const position=p.x;g.move(p,1,0,.1,true);assert.equal(p.x,position);
  Object.assign(g.ball,{x:p.x+.3,y:.5,lastHit:1});p.cooldown=0;
  assert.equal(g.hit(p,'slice'),false,'cannot swing while getting up');
  for(let n=0;n<65;n++)g.updateDive(p,1/120);
  assert.equal(p.diveRecovery,0);assert.ok(p.diveCooldown>0);assert.equal(g.startDive(p),false);
  for(let n=0;n<120;n++)g.updateDive(p,1/120);
  assert.equal(g.startDive(p),true);
});

test('diving does not allow high contacts or volleying an unbounced serve',()=>{
  const {game:g,player:p}=fixture();g.startDive(p);p.diveTime=.3;g.ball.x=1.5;g.ball.y=2;
  assert.equal(g.hit(p,'smash'),false);
  Object.assign(g.ball,{y:.5,serving:true,bounces:0});assert.equal(g.hit(p,'slice'),false);
  Object.assign(g.ball,{serving:false,bounces:1,x:-1});assert.equal(g.hit(p,'slice'),false,'cannot reach behind the dive');
});

test('pause freezes a dive, court limits remain solid, and a new point clears the pose',()=>{
  const {game:g,player:p}=fixture();p.x=7.3;g.ball.x=10;g.startDive(p);
  g.paused=true;const before={x:p.x,time:p.diveTime,stamina:p.stamina};g.update(1);
  assert.deepEqual({x:p.x,time:p.diveTime,stamina:p.stamina},before);
  g.paused=false;for(let n=0;n<60;n++)g.updateDive(p,1/120);
  assert.ok(p.x<=7.4&&p.z>=.7);g.preparePoint();assert.equal(p.diveTime,0);assert.equal(p.diveRecovery,0);assert.equal(p.diveCooldown,0);assert.equal(divePose(p),null);
});

test('player two can dive independently and player-one dive can be rebound',()=>{
  const {game:g,player:p,store}=fixture({local:true});
  g.input('ArrowLeft',true);g.input('Numpad0',true);assert.ok(g.players[1].diveTime>0);assert.equal(p.diveTime,0);
  store.data.settings.keys.dive='KeyV';g.input('KeyX',true);assert.equal(p.diveTime,0);g.input('KeyV',true);assert.ok(p.diveTime>0);
});

test('dive flight and get-up poses remain finite and finish upright',()=>{
  for(const time of [.44,.35,.2,.05]){const pose=divePose({diveTime:time,diveRecovery:0});assert.ok(pose.height>=0);assert.ok(Number.isFinite(pose.tilt));}
  const landing=divePose({diveTime:0,diveRecovery:.5}),recovering=divePose({diveTime:0,diveRecovery:.1});assert.ok(landing.tilt>recovering.tilt);assert.equal(divePose({diveTime:0,diveRecovery:0}),null);
});

test('existing standard controls upgrade without losing saved career progress',()=>{
  let data=JSON.stringify({version:1,name:'Carlos',credits:940,wins:8,seenGuide:true,settings:{keys:LEGACY_KEYS}});
  const storage={getItem:()=>data,setItem:(key,value)=>{data=value;}};
  const store=new SaveStore(storage);
  assert.deepEqual(store.data.settings.keys,DEFAULT_KEYS);assert.equal(store.controlsUpdated,true);assert.equal(store.data.credits,940);assert.equal(store.data.name,'Carlos');assert.equal(store.data.wins,8);assert.equal(store.data.seenGuide,false);
  assert.equal(new SaveStore(storage).controlsUpdated,false,'migration is applied once');
});

test('custom bindings survive migration and the dive key avoids conflicts',()=>{
  const custom={...LEGACY_KEYS,topspin:'KeyX'};
  const store=new SaveStore({getItem:()=>JSON.stringify({version:1,settings:{keys:custom}}),setItem(){}});
  assert.equal(store.data.settings.keys.topspin,'KeyX');assert.equal(store.data.settings.keys.sprint,'Space');assert.notEqual(store.data.settings.keys.dive,'KeyX');
  const bindings=Object.values(store.data.settings.keys);assert.equal(new Set(bindings).size,bindings.length);
});

test('compact shot and serve keys dispatch their gameplay actions',()=>{
  const {game:g}=fixture();
  for(const action of ['topspin','slice','flat','lob','smash']){g.input(DEFAULT_KEYS[action],true);assert.equal(g.pending[0].shot,action);g.input(DEFAULT_KEYS[action],false);}
  g.preparePoint();g.input(DEFAULT_KEYS.serve,true);assert.equal(g.state,'toss');
});
