# Tennis Legends

A full-screen, procedural 3D tennis game for desktop browsers. The source is plain JavaScript ES modules with Three.js 0.180.0 included locally and pinned in an import map. No npm installation or build dependency is required.

## Single-file release

Run `npm run build:standalone` to generate `standalone/index.html`. This page embeds all game modules, Three.js, styling, fonts, and third-party licenses. It can be opened directly in a current Chrome or Edge browser, or uploaded as the only file needed to run the game on GitHub Pages. The original development `index.html` below still uses separate source files.

Run `npm run check:standalone` to check the embedded module graph and packaged gameplay. The standalone page was also opened successfully from a local file in headless Chrome with software WebGL: the loading screen cleared and the game menu rendered. This startup check does not establish performance on other hardware.

## Launch

On Windows, double-click **Play Tennis Legends.cmd**. It starts a local server and opens your default browser. Keep its console open while playing.

Alternatively, with Node.js 20 or newer:

```sh
npm run dev
```

Open the printed local URL, normally `http://127.0.0.1:57123`. The launcher uses a stable port so browser saves persist between sessions. Close a previous game server before starting another. Changing the origin or port creates a separate browser save. Do not open `index.html` directly as a file: browsers restrict module loading from file URLs.

A WebGL 2 capable browser is required. Three.js and the interface fonts are bundled in `vendor/`, including their licenses; no internet connection is needed to play. Game logic, save data, sounds, and procedural visual assets run locally. The launcher resolves the Windows command processor by absolute path, handles browser-opening errors without stopping the server, and reuses an existing game server. There are no external audio or model assets.

## GitHub Pages

Upload the complete `src` and `vendor` folders alongside `index.html`, preserving their folder names. Upload `.nojekyll` too so GitHub serves every game asset directly. Uploading only the files outside those folders leaves the game unable to load.

```text
index.html
.nojekyll
src/
  main.js
  style.css
  ...other game modules
vendor/
  three.module.min.js
  three.core.min.js
  ...fonts and licenses
```

In the repository's Settings > Pages, choose Deploy from a branch, then the branch containing these files and `/ (root)`. Alternatively, build locally and upload everything **inside** `dist` to that publishing folder. Keep an existing `CNAME` file if you use a custom domain. Wait for the Pages deployment to finish, then press Ctrl+Shift+R on the game page.

## Play

- WASD moves; left Shift sprints and consumes stamina.
- Hold Q for topspin, E for slice, F for a flat drive, R for lob, or C for smash. Release shortly before contact for a controlled shot. Longer preparation adds power.
- Movement direction at contact aims the shot. Left/right chooses placement; toward the net hits deeper; away from the net hits shorter. Neutral input sends a safe cross-court ball.
- Space tosses a serve. Press it again near the toss apex to strike. A missed timing window produces a weaker automatic strike and can fault.
- X dives in your movement direction. With no movement key held, it dives toward the ball. A dive automatically attempts a low reaching slice, uses 28% stamina, and has a short landing recovery plus a 1.8-second cooldown.
- Escape/P pauses. H shows the guide. F11 toggles fullscreen.
- Rally assistance is enabled initially: nearby bounced balls return automatically, and a landing ring helps positioning. Shot keys override assistance. Disable it in Settings for manual contact.
- Player 2 uses arrow keys, right Ctrl for sprint, Numpad 1/2/3 for topspin/slice/flat, Numpad 5 for lob, Numpad 4 for smash, Numpad 0 for dive, and Numpad Enter for serve. Alternative shot keys are `/`, `.`, `,`, quote, and semicolon; right Shift serves, and backslash dives.

Existing default bindings automatically migrate to the compact layout. Custom bindings and career progress are preserved; use Settings ? Restore default controls to switch a custom layout to the compact defaults.

## Modes and progression

Exhibition supports singles, doubles with AI partners, and local two-player opposition. Four difficulty levels and seven fictional opponents provide five playing styles. Full matches use advantage games, six-game sets, seven-point tiebreaks at 6–6, and best-of-one, three, or five sets. The broadcast camera stays behind the primary player.

The Legends Cup is an eight-player, three-round tournament. Player matches are played in full; the other draw matches are simulated. Progress saves between rounds. Career events unlock with experience. Speed, power, and control upgrades apply only to career events. Exhibition and local play retain equal base attributes. Cosmetic purchases do not improve performance.

Practice includes serve timing, cooperative rallies, target hitting, shot placement, and movement circuits. Each session lasts 90 active seconds and awards credits and XP. Profile appearance, bindings, preferences, credits, upgrades, achievements, and tournament progress use local storage. An in-progress rally or match is not resumed after closing the browser.

Hard, clay, grass, and indoor courts have different rebound and friction characteristics. Models, textures, seating, crowd, lighting, equipment, particles, animations, and stadium branding are generated in code. Audio uses original Web Audio synthesis, with optional browser speech for the umpire.

## Architecture

| File | Responsibility |
| --- | --- |
| `src/physics.js` | Fixed-step ball flight, drag, gravity, spin, collision, surface response, prediction |
| `src/rules.js` | Isolated tennis scoring and service order |
| `src/controls.js` | Compact keyboard bindings and saved-control migration |
| `src/dive.js` | Dive tuning and flight/recovery animation poses |
| `src/game.js` | Movement, contact windows, AI, match lifecycle, practice |
| `src/scene.js` | Three.js stadium, articulated players, camera, effects |
| `src/ui.js` | Menus, HUD, tournaments, career, customisation, settings |
| `src/save.js` | Save schema, migration defaults, rewards and purchases |
| `src/audio.js` | Original procedural effects, ambience, speech and fanfare |

## Checks and packaging

```sh
npm test
npm run build
npm run qa
```

Tests cover tennis scoring, tiebreak service order, continuous physics, trajectories, bounce differences, net/tape contact, serves, AI rallies, doubles, practice completion, pause, and persistence. `npm run build` creates a static `dist` folder. Host that folder on any HTTPS static server. The browser QA script uses an installed Windows Chrome and writes screenshots/results to ignored `artifacts/`.

The implementation environment passed automated tests and static HTTP checks. Graphical QA could not complete: its sandboxed Chrome exited, and Edge reported an unusable GPU process. Browser performance, rendered layout, and subjective gameplay feel therefore remain unverified. Private Sites publication was attempted but the environment could not connect to the source repository host; the local project and static build remain available.

The presentation is original procedural 3D, with simplified articulated characters and synthesized stadium sound. It does not include photorealistic scanned athletes, motion capture, online multiplayer, or a commercial asset library.

## References

Court dimensions, scoring, service faults and tiebreak conventions were checked against the [2026 ITF Rules of Tennis](https://www.itftennis.com/media/7221/2026-rules-of-tennis-english.pdf). Rendering uses the [Three.js WebGLRenderer](https://threejs.org/docs/pages/WebGLRenderer). Standard seven-point tiebreaks are used in all sets rather than tournament-specific deciding-set variants.
