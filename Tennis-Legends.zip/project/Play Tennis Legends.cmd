@echo off
title Tennis Legends
cd /d "%~dp0"
set "tennisNode="
for %%N in (node.exe) do set "tennisNode=%%~$PATH:N"
if not defined tennisNode if exist "%ProgramFiles%\nodejs\node.exe" set "tennisNode=%ProgramFiles%\nodejs\node.exe"
if not defined tennisNode if exist "F:\Program Files\nodejs\node.exe" set "tennisNode=F:\Program Files\nodejs\node.exe"
if not defined tennisNode (
  echo Node.js could not be found. Install Node.js 20 or newer, then open this launcher again.
  pause
  exit /b 1
)
"%tennisNode%" tools\launch.mjs
if errorlevel 1 pause
